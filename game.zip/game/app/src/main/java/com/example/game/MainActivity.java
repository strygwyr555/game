package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int amount=0;
    int chance=3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btn1=(Button) findViewById(R.id.button1);
        final Button btn2=(Button) findViewById(R.id.button2);
        final Button btn3=(Button) findViewById(R.id.button3);
        final Button btn4=(Button) findViewById(R.id.button4);
        final Button btn5=(Button) findViewById(R.id.button5);
        final Button btn6=(Button) findViewById(R.id.button6);
        final Button btn7=(Button) findViewById(R.id.button7);
        final Button btn8=(Button) findViewById(R.id.button8);
        final Button btn9=(Button) findViewById(R.id.button9);
        final Button btnr=(Button) findViewById(R.id.reset);

        TextView text1=(TextView) findViewById(R.id.textView1);
        final TextView text2=(TextView) findViewById(R.id.textView2);
        final TextView text3=(TextView) findViewById(R.id.textView3);


            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn1.setClickable(false);
                    }
                    else {
                        btn1.setText("0");
                        amount += 0;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn1.setClickable(false);
                    }

                }
            });
            btn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn2.setClickable(false);
                    }
                    else {
                        btn2.setText("1");
                        amount += 1;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn2.setClickable(false);
                    }

                }
            });
            btn3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn3.setClickable(false);
                    }
                    else {
                        btn3.setText("6");
                        amount += 6;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        ;
                        btn3.setClickable(false);
                    }
                }
            });
            btn4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn4.setClickable(false);
                    }
                    else {
                        btn4.setText("1");
                        amount += 1;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn4.setClickable(false);
                    }
                }
            });
            btn5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn5.setClickable(false);
                    }
                    else {
                        btn5.setText("0");
                        amount += 0;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn5.setClickable(false);
                    }

                }
            });
            btn6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn6.setClickable(false);
                    }
                    else {
                        btn6.setText("2");
                        amount += 2;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn6.setClickable(false);
                    }
                }
            });
            btn7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn7.setClickable(false);
                    }
                    else {
                        btn7.setText("1");
                        amount += 1;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn7.setClickable(false);
                    }
                }
            });
            btn8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn8.setClickable(false);
                    }
                    else {
                        btn8.setText("3");
                        amount += 3;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn8.setClickable(false);
                    }

                }
            });
            btn9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(chance==0)
                    {
                        btn9.setClickable(false);
                    }
                    else {
                        btn9.setText("0");
                        amount += 0;
                        text3.setText("Amount Won " + String.valueOf(amount));
                        chance -= 1;
                        text2.setText("Chance left " + String.valueOf(chance));
                        btn9.setClickable(false);
                    }

                }
            });

            btnr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    btn1.setText("*");
                    btn1.setClickable(true);
                    btn2.setText("*");
                    btn2.setClickable(true);
                    btn3.setText("*");
                    btn3.setClickable(true);
                    btn4.setText("*");
                    btn4.setClickable(true);
                    btn5.setText("*");
                    btn5.setClickable(true);
                    btn6.setText("*");
                    btn6.setClickable(true);
                    btn7.setText("*");
                    btn7.setClickable(true);
                    btn8.setText("*");
                    btn8.setClickable(true);
                    btn9.setText("*");
                    btn9.setClickable(true);
                    amount = 0;
                    chance = 3;
                    text3.setText("Amount Won 0");
                    text2.setText("Chance left 3");
                }
            });






    }
}

